var Board = require("../").Board;

var board = new Board("/dev/cu.usbmodem1411", function() {
  console.log(board.pins[8].value === 1 ? "PASS" : "FAIL");
});
// Board.requestPort(function(error, port) {
//   if (error) {
//     console.log(error);
//     return;
//   }
//   var board = new Board(port.comName, {
//     // reportInitialState: true
//   });

//   board.on("ready", function() {
//     // var a = 7;
//     // var b = 8;

//     // console.log("Pin 7 is %s (Expected LOW)", this.pins[a].value === 0 ? "LOW" : "HIGH");
//     // console.log("Pin 8 is %s (Expected HIGH)", this.pins[b].value === 1 ? "HIGH" : "LOW");

//     // this.pins.forEach(pin => console.log(pin.value));

//     // this.on("report-initial-state", data => console.log(data));


//     this.pinMode(8, this.MODES.INPUT);
//     this.digitalRead(8, state => console.log(state));
//   });
// });

var Board = require("../");

Board.requestPort(function(error, port) {
  if (error) {
    console.log(error);
    return;
  }
  var board = new Board(port.comName);

  board.on("ready", function() {
    var settings = {
      pin: 3,
      value: 1,
      pulseOut: 5
    };

    var continuousRead = function() {
      this.pingRead(settings, function(duration) {
        console.log(duration);

        setTimeout(continuousRead, 50);
      });
    }.bind(this);

    continuousRead();
  });
});


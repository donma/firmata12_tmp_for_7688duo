var Board = require("../");

Board.requestPort(function(error, port) {
  if (error) {
    console.log(error);
    return;
  }
  var board = new Board(port.comName);

  board.on("ready", function() {
    board.pinMode(8, board.MODES.OUTPUT);
    board.pinMode(10, board.MODES.INPUT);
    board.digitalRead(10, function(data) {

      console.log(data);

      console.log(board.ports[1]);

        // done();
    });
    board.digitalWrite(8, 0);
    board.digitalWrite(8, 1);
  });
});

var Board = require("../");
var EtherPort = require("etherport");
var board = new Board(new EtherPort(3030));

board.on("ready", function() {
  var pin = 2;
  var state = 1;

  board.pinMode(pin, board.MODES.OUTPUT);

  setInterval(function() {
    board.digitalWrite(pin, (state ^= 1));
  }, 500);
});

// var Board = require("../lib/firmata").Board;
// var SerialPort = require("serialport").SerialPort;
// var board = new Board("/dev/cu.usbmodem1411");


var SerialPort = require("serialport").SerialPort;
var options = {
  comname: "/dev/cu.usbmodem1411",
  baudRate: 57600,
  bufferSize: 1
};
var sp = new SerialPort(options);

console.log(sp);
// sp.open(options);
